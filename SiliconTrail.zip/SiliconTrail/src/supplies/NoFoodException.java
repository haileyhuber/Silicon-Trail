package supplies;

public class NoFoodException extends Exception {}