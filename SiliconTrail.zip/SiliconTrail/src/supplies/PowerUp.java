package supplies;

public interface PowerUp extends Food {
	int getDuration();
}