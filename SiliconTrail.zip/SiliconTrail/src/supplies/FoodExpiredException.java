package supplies;

public class FoodExpiredException extends Exception {}