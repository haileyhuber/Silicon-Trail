package view;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import person.Person;
import model.Adventure;
import model.Squad;

public class AdventureView extends JPanel {

	private Adventure adventure;
	
	public AdventureView(Adventure adventure) {
		this.adventure = adventure;
		
		setLayout(new BorderLayout());
		
		Squad s = adventure.getSquad();
		Person p = s.getPlayer(0);
		
		PersonView pv = new PersonView(p);
		
		add(pv, BorderLayout.CENTER);
		System.out.println("enter 'help' to see a list of possible commands");
	}
}
