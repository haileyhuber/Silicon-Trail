package model;

public class InsufficientFundsException extends Exception {

}
