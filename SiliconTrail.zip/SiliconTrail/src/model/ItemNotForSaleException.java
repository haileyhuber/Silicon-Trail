package model;

public class ItemNotForSaleException extends Exception {

}
