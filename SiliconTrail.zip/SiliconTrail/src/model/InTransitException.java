package model;

public class InTransitException extends Exception {

}
